var ttData = {
        "enero": [
            {
                "score": 2744,
                "name": "#PalabrasQueDuelen",
                "category":"popular"
            },
            {
                "score": 2637,
                "name": "En Gitania",
                "category":"popular"
            },
            {
                "score": 2488,
                "name": "Reyes",
                "category":"estacional"
            },
            {
                "score": 2287,
                "name": "#seriesdemivida",
                "category":"popular"
            },
            {
                "score": 2183,
                "name": "#30thingsaboutme",
                "category":"popular"
            },
            {
                "score": 2180,
                "name": "#peliculascontuputamadre",
                "category":"popular"
            },
            {
                "score": 2129,
                "name": "#indirectasparafollar",
                "category":"popular"
            },
            {
                "score": 2118,
                "name": "Costa Concordia",
                "category":"sucesos"
            },
            {
                "score": 1964,
                "name": "#FrasesQueArruinanUnaPrimeraCita",
                "category":"popular"
            },
            {
                "score": 1950,
                "name": "#el2012prometo",
                "category":"estacional"
            }
        ],
        "febrero": [
            {
                "score": 6687,
                "name": "#PrimaveraValenciana",
                "category":"social"

            },
            {
                "score": 3252,
                "name": "#Claaaaaaaro",
                "category":"popular"

            },
            {
                "score": 3018,
                "name": "#premiosgoya",
                "category":"estacional"
            },
            {
                "score": 2941,
                "name": "#Pel\u00edculasQueVer\u00edaMilVeces",
                "category":"popular"
            },
            {
                "score": 2744,
                "name": "#PalabrasQueDuelen",
                "category":"popular"
            },
            {
                "score": 2637,
                "name": "En Gitania",
                "category":"popular"
            },
            {
                "score": 2511,
                "name": "#razones19F",
                "category":"social"
            },
            {
                "score": 2488,
                "name": "Reyes",
                "category":"estacional"
            },
            {
                "score": 2463,
                "name": "R.I.P Whitney Houston",
                "category":"sucesos"
            },
            {
                "score": 2387,
                "name": "#ComoDejarATuPareja",
                "category":"popular"
            }
        ],
        "marzo": [
            {
                "score": 6687,
                "name": "#PrimaveraValenciana",
                "category":"social"
            },
            {
                "score": 4216,
                "name": "#violenciaestructural",
                "category":"popular"
            },
            {
                "score": 3252,
                "name": "#Claaaaaaaro",
                "category":"popular"
            },
            {
                "score": 3018,
                "name": "#premiosgoya",
                "category":"estacional"
            },
            {
                "score": 2941,
                "name": "#Pel\u00edculasQueVer\u00edaMilVeces",
                "category":"popular"
            },
            {
                "score": 2882,
                "name": "#frasesqueparecenpornosinserlo",
                "category":"popular"
            },
            {
                "score": 2744,
                "name": "#PalabrasQueDuelen",
                "category":"popular"
            },
            {
                "score": 2685,
                "name": "#29NoaLaHuelgaGeneral",
                "category":"social"
            },
            {
                "score": 2637,
                "name": "En Gitania",
                "category":"popular"
            },
            {
                "score": 2511,
                "name": "#razones19F",
                "category":"social"
            }
        ]
    };